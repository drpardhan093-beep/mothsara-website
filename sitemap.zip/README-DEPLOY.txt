DR AM DIGITAL SOLUTION - SEO UPDATE

Files included:
- index.html
- about.html
- services.html
- seo-services.html
- contact.html
- sitemap.xml
- robots.txt
- google039bfab14f930c83.html (preserved verification file)

How to publish:
1. Download and extract this ZIP.
2. In the GitHub mothsara-website repository, upload/replace the files at the repository root.
3. Keep the repository name and GitHub Pages settings unchanged.
4. Commit the update.
5. Check each page URL and submit sitemap.xml in Search Console.

Important:
- The existing public phone number from the supplied contact.html was retained.
- No email address was invented. Contact is via phone/WhatsApp.
- SEO rankings and indexing are not guaranteed by metadata or sitemap submission.
